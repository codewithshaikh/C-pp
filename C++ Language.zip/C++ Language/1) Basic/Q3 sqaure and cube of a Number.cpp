//Q3 program to find square and cube of a number

#include<iostream>
using namespace std;

int main()
{
	int a,sq,cu;
	cout<<"Enter a Number";
	cin>>a;
	sq=a*a;
	cu=a*a*a;
	cout<<"\nSqaure of a Number is :"<<sq;
	cout<<"\nCube of a Number is :"<<cu;

	return 0;
}
