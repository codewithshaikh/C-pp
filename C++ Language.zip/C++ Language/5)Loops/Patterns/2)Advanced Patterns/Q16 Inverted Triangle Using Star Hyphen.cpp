//Q16 Program to Print Inverted Triangle Using Star Hyphen combination

#include<iostream>
using namespace std;
int main()
{
	int i , j , k , n ;
	cout<<"\nEnter Number of Rows: ";
	cin>>n;
	cout<<"\nInverted Triangle Using Star Hyphen combination:\n\n";
	for(i=1 ; i)
	return 0;
}
