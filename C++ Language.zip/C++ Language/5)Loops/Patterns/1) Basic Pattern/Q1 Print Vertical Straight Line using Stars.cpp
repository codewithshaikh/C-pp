//Q1 Program to print Vertical Straight Line using Stars

#include<iostream>
using namespace std;

int main()
{
	int n , i;
	cout<<"\nEnter the last Limit: ";
	cin>>n;
	cout<<endl;
	for(i=1 ; i<=n ; i++)
	{
		cout<<"*"<<endl;
	}
}
