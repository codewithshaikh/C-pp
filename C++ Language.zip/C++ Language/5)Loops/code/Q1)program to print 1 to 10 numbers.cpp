//Q1)program to print 1 to 10 numbers using loop

#include<iostream>
using namespace std;

int main()
{
	int i=1;
	while(i<=10)
	{
		cout<<i<<endl;
		i++;
	}
	
}
