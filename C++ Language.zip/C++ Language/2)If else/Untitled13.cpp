#include<iostream>
using namespace std;

int main(){
 char a1;
	
 	cout<<"Enter the character : ";
 	cin>>a1;
 	
 	if(a1=='a' || a1=='e'|| a1=='i' || a1=='o'|| a1=='u'){
 		cout<<"It is vowel";	 
	 }
     else{
	 	cout<<"It is  a consonant";
	 }
	 
	 
	 	return 0;
}
