//Q5 program to check Even or Odd
#include<iostream>
using namespace std;

int main()
{
	int a;
	cout<<"Enter a Numbers:";
	cin>>a;
    if(a%2==0)
    {
    	cout<<a <<" is Even";
	}
	else
	{
		cout<<a <<" is Odd";
	}
	return 0;
}
